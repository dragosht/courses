/*
 * Threads scheduler io tests
 *
 * 2012, Operating Systems
 */

#include "scheduler_test.h"

#include <stdio.h>
#include <stdlib.h>



#define SO_DEV0				0
#define SO_DEV1				1
#define SO_DEV2				2
#define SO_DEV3				3

#define SO_PREEMPT_UNITS	3

static unsigned exec_time = 0;
static unsigned exec_devs = 0;
static unsigned last_priority = 0;
static unsigned exec_priority = 0;
static unsigned test_exec_status = SO_TEST_FAIL;


/*
 * 16) Test IO devices
 *
 * tests if the scheduler properly uses the IO devices
 */

static void test_sched_handler_16(unsigned prio)
{
	if (prio != exec_priority)
		so_fail("invalid exec priority");

	if (so_wait(exec_devs) == 0)
		so_fail("invalid waiting device");

	if (so_signal(exec_devs) >= 0)
		so_fail("invalid signalling device");

	if (so_signal(SO_DEV0) != 0)
		so_fail("too many threads woken");

	test_exec_status = SO_TEST_SUCCESS;
}

void test_sched_16(void)
{
	test_exec_status = SO_TEST_FAIL;
	exec_devs = get_rand(1, SO_MAX_UNITS);
	exec_priority = get_rand(1, SO_MAX_PRIO);

	if (so_init(SO_MAX_UNITS, exec_devs) < 0) {
		so_error("initialization failed");
		goto test;
	}

	if (so_fork(test_sched_handler_16, exec_priority) == INVALID_TID) {
		so_error("cannot create new task");
		goto test;
	}

test:
	sched_yield();
	so_end();

	basic_test(test_exec_status);
}


/*
 * 17) Test IO schedule
 *
 * tests if the scheduler properly handles IO devices
 */

static void test_sched_handler_17_signal(unsigned dummy)
{
	unsigned step;

	/* check if wait was called */
	if (exec_time != 2) {
		so_error("thread didn't execute wait");
		return;
	}

	/* keep the other thread waiting longer than the preemption time */
	for (step = 0; step <= SO_PREEMPT_UNITS; step++) {
		exec_time++;
		so_exec();
	}

	/* if executed before signal, fail */
	if (test_exec_status == SO_TEST_SUCCESS)
		test_exec_status = SO_TEST_FAIL;
	/* finally release the waiting thread */
	so_signal(SO_DEV0);
}

static void test_sched_handler_17_wait(unsigned dummy)
{
	exec_time++;
	so_fork(test_sched_handler_17_signal, 0);
	exec_time++;
	so_wait(SO_DEV0);

	/* check if I waited more than preemption time */
	if (exec_time < SO_PREEMPT_UNITS + 2) {
		so_error("scheduled while waiting");
		return;
	}

	so_exec();
	test_exec_status = SO_TEST_SUCCESS;
}

/* tests the IO functionality */
void test_sched_17(void)
{
	/* ensure that the thread gets to execute wait */
	so_init(SO_PREEMPT_UNITS, 1);

	so_fork(test_sched_handler_17_wait, 0);

	sched_yield();
	so_end();

	basic_test(test_exec_status);
}


/*
 * 18) Test priorities and IO
 *
 * tests if the scheduler properly handles IO devices and preemption
 */

/* fails if the last priority set is not _p */
#define FAIL_IF_NOT_PRIO(_p, _m) \
	do { \
		if ((_p) != last_priority) { \
			test_exec_status = SO_TEST_FAIL; \
			so_fail(_m); \
		} \
		last_priority = priority;\
	} while (0)

/*
 * Threads are mixed to wait/signal lower/higher priorities
 * P2 refers to the task with priority 2
 */
static void test_sched_handler_18(unsigned priority)
{
	switch (priority) {
	case 1:
		/* P2 should be the one that executed last */
		FAIL_IF_NOT_PRIO(2, "should have been woke by P2");
		if (so_signal(SO_DEV3) == 0)
			so_fail("dev3 does not exist");
		so_exec();
		FAIL_IF_NOT_PRIO(1, "invalid preemption");
		if (so_signal(SO_DEV0) != 2)
			so_fail("P1 should wake P3 and P4 (dev0)");
		FAIL_IF_NOT_PRIO(2, "preempted too early");
		if (so_signal(SO_DEV1) != 1)
			so_fail("P1 should wake P3 (dev1)");
		FAIL_IF_NOT_PRIO(2, "woke by someone else");
		if (so_signal(SO_DEV0) != 1)
			so_fail("P1 should wake P4 (dev0)");
		FAIL_IF_NOT_PRIO(4, "should be the last one");
		so_exec();
		FAIL_IF_NOT_PRIO(1, "someone else was running");
		break;

	case 2:
		last_priority = 2;
		/* wait for dev 3 - invalid device */
		if (so_wait(SO_DEV3) == 0)
			so_fail("dev3 does not exist");
		/* spawn all the tasks */
		so_fork(test_sched_handler_18, 4);
		so_fork(test_sched_handler_18, 3);
		so_fork(test_sched_handler_18, 1);
		so_exec();
		so_exec();

		/* no one should have ran until now */
		FAIL_IF_NOT_PRIO(2, "somebody else ran before P2");
		if (so_wait(SO_DEV1) != 0)
			so_fail("cannot wait on dev1");
		FAIL_IF_NOT_PRIO(3, "should run after P3");
		if (so_wait(SO_DEV2) != 0)
			so_fail("cannot wait on dev2");
		FAIL_IF_NOT_PRIO(3, "only P3 could wake me");
		so_exec();
		break;

	case 3:
		if (so_wait(SO_DEV0) != 0)
			so_fail("P3 cannot wait on dev0");
		FAIL_IF_NOT_PRIO(4, "priority order violated");
		if (so_wait(SO_DEV1) != 0)
			so_fail("P3 cannot wait on dev1");
		FAIL_IF_NOT_PRIO(1, "someone else woke P3");
		if (so_signal(SO_DEV2) != 1)
			so_fail("P3 should wake P2 (dev2)");
		break;

	case 4:
		if (so_wait(SO_DEV0) != 0)
			so_fail("P4 cannot wait on dev0");
		FAIL_IF_NOT_PRIO(1, "lower priority violation");
		if (so_signal(SO_DEV1) != 1)
			so_fail("P4 should wake P2 (dev1)");
		if (so_wait(SO_DEV0) != 0)
			so_fail("P4 cannot wait on dev0");
		FAIL_IF_NOT_PRIO(1, "someone else woke dev0");
		break;
	}
}

/* tests the IO and priorities */
void test_sched_18(void)
{
	test_exec_status = SO_TEST_SUCCESS;

	so_init(1, 3);

	so_fork(test_sched_handler_18, 2);

	sched_yield();
	so_end();

	basic_test(/* TODO: check here test_exec_status && */ last_priority == 1);
}


#undef FAIL_IF_NOT_PRIO
