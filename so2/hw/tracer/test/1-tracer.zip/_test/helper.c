#ifndef _HELPER__
#define _HELPER__

struct test_params
{
	char name[MAX];
	int kno; /* kmalloc no */
	int ksize[MAX];
	int fsize[MAX];
	int sno; /* schedule no */
};

#endif
