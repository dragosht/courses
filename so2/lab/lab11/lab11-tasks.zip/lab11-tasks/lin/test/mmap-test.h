#ifndef __SO2MMAP_H__
#define __SO2MMAP_H__ 1

#define PROC_ENTRY_NAME	"my-proc-entry"

#endif
